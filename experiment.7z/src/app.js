let test = () => console.log('hello worlds');

test();